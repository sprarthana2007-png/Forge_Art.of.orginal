/*
 * Copyright (c) 2022, 2025, Oracle and/or its affiliates. All rights reserved.
 * ORACLE PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 *
 */
package java.lang.classfile;

import java.util.function.Consumer;
import java.util.function.Supplier;

import jdk.internal.classfile.impl.TransformImpl;

import static java.util.Objects.requireNonNull;

/**
 * A transformation on streams of {@link CodeElement}.  The stream can come
 * from a {@link CodeModel}, or a handler to a {@link CodeBuilder} as in
 * {@link CodeBuilder#transforming}.
 * <p>
 * Refer to {@link ClassFileTransform} for general guidance and caution around
 * the use of transforms for structures in the {@code class} file format.
 * <p>
 * A code transform can be lifted to a method or a class transform via {@link
 * MethodTransform#transformingCode(CodeTransform)} and {@link
 * ClassTransform#transformingMethodBodies(CodeTransform)}, transforming only
 * the {@link CodeModel} within those structures and passing all other elements
 * to the builders.
 *
 * @see CodeModel
 * @see MethodBuilder#transformCode
 * @see CodeBuilder#transforming
 * @since 24
 */
@FunctionalInterface
public non-sealed interface CodeTransform
        extends ClassFileTransform<CodeTransform, CodeElement, CodeBuilder> {

    /**
     * A code transform that passes all elements to the builder.
     */
    CodeTransform ACCEPT_ALL = new CodeTransform() {
        @Override
        public void accept(CodeBuilder builder, CodeElement element) {
            builder.with(element);
        }
    };

    /**
     * Creates a stateful code transform from a {@link Supplier}.  The supplier
     * will be invoked for each transformation.
     *
     * @param supplier a {@link Supplier} that produces a fresh transform object
     *                 for each traversal
     * @return the stateful code transform
     */
    static CodeTransform ofStateful(Supplier<CodeTransform> supplier) {
        return new TransformImpl.SupplierCodeTransform(requireNonNull(supplier));
    }

    /**
     * Creates a code transform that passes each element through to the builder,
     * and calls the specified function when transformation is complete.
     *
     * @param finisher the function to call when transformation is complete
     * @return the code transform
     */
    static CodeTransform endHandler(Consumer<CodeBuilder> finisher) {
        requireNonNull(finisher);
        return new CodeTransform() {
            @Override
            public void accept(CodeBuilder builder, CodeElement element) {
                builder.with(element);
            }

            @Override
            public void atEnd(CodeBuilder builder) {
                finisher.accept(builder);
            }
        };
    }

    /**
     * @implSpec
     * The default implementation returns this code transform chained with another
     * code transform from the argument. Chaining of two transforms requires to
     * involve a chained builder serving as a target builder for this transform
     * and also as a source of elements for the downstream transform.
     */
    @Override
    default CodeTransform andThen(CodeTransform t) {
        return new TransformImpl.ChainedCodeTransform(this, requireNonNull(t));
    }
}
